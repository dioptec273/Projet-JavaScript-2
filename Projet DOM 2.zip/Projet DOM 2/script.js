.container {
    width: 300px;
    margin: 50px auto;
    text-align: center;
    font-family: Arial, sans-serif;
}

#color-box {
    width: 200px;
    height: 200px;
    margin: 20px auto;
    background-color: #3498db;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
}

#change-color-btn {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #2ecc71;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

#change-color-btn:hover {
    background-color: #27ae60;